package pt.uma.structure;

// This class stores invariant of type data!= null or flag=flase etc

public class E_Bool_Invariant {
	
	String variable;
	String value;
	
	
	public E_Bool_Invariant(String variable, String value){
		this.variable=variable;
		this.value=value;
	
	}
	
	public String getVariable(){
		return variable;
	}

	public String getValue(){
		return value;
	}
}
